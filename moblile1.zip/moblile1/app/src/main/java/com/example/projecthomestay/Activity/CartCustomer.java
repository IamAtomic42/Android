package com.example.projecthomestay.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.projecthomestay.R;

public class CartCustomer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_customer);
    }
}